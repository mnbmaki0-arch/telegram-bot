## Packages
framer-motion | Smooth animations for page transitions and micro-interactions
date-fns | Formatting dates for transaction history

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
