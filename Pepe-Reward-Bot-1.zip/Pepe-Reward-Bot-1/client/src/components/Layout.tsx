import { Navigation } from "./Navigation";

export function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col md:flex-row">
      <Navigation />
      <main className="flex-1 md:ml-64 pb-20 md:pb-0 px-4 py-6 md:px-8 md:py-8 max-w-7xl mx-auto w-full">
        {children}
      </main>
    </div>
  );
}
