import { ReactNode } from "react";
import { cn } from "@/lib/utils";

interface StatCardProps {
  title: string;
  value: string | number;
  icon: ReactNode;
  trend?: string;
  className?: string;
}

export function StatCard({ title, value, icon, trend, className }: StatCardProps) {
  return (
    <div className={cn("glass-card rounded-2xl p-6 relative overflow-hidden group", className)}>
      <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity transform group-hover:scale-110 duration-500">
        {icon}
      </div>
      
      <div className="relative z-10">
        <div className="flex items-center gap-3 mb-2 text-muted-foreground">
          <div className="p-2 rounded-lg bg-primary/10 text-primary">
             {icon}
          </div>
          <span className="text-sm font-medium">{title}</span>
        </div>
        
        <div className="text-3xl font-display font-bold text-white tracking-tight">
          {value}
        </div>
        
        {trend && (
          <p className="text-xs text-primary mt-2 font-medium">
            {trend}
          </p>
        )}
      </div>
    </div>
  );
}
