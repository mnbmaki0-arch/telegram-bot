import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";

// GET /api/transactions
export function useTransactions() {
  return useQuery({
    queryKey: [api.transactions.list.path],
    queryFn: async () => {
      const res = await fetch(api.transactions.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch transactions");
      return api.transactions.list.responses[200].parse(await res.json());
    },
  });
}

// POST /api/transactions/withdraw
export function useWithdraw() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: { amount: number }) => {
      const validated = api.transactions.withdraw.input.parse(data);
      const res = await fetch(api.transactions.withdraw.path, {
        method: api.transactions.withdraw.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });
      
      if (!res.ok) {
        if (res.status === 400) {
           const error = api.transactions.withdraw.responses[400].parse(await res.json());
           throw new Error(error.message);
        }
        throw new Error("Withdrawal failed");
      }
      return api.transactions.withdraw.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.transactions.list.path] });
      queryClient.invalidateQueries({ queryKey: ["/api/profiles/me"] }); // Update balance
    },
  });
}

// POST /api/transactions/deposit
export function useDeposit() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: { amount: number }) => {
      const validated = api.transactions.deposit.input.parse(data);
      const res = await fetch(api.transactions.deposit.path, {
        method: api.transactions.deposit.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });
      
      if (!res.ok) {
        if (res.status === 400) {
           const error = api.transactions.deposit.responses[400].parse(await res.json());
           throw new Error(error.message);
        }
        throw new Error("Deposit failed");
      }
      return api.transactions.deposit.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.transactions.list.path] });
      queryClient.invalidateQueries({ queryKey: ["/api/profiles/me"] }); // Update balance
    },
  });
}

// ADMIN HOOKS

// GET /api/admin/withdrawals
export function useAdminWithdrawals() {
  return useQuery({
    queryKey: [api.admin.withdrawals.list.path],
    queryFn: async () => {
      const res = await fetch(api.admin.withdrawals.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch withdrawals");
      return api.admin.withdrawals.list.responses[200].parse(await res.json());
    },
  });
}

// POST /api/admin/withdrawals/:id/approve
export function useApproveWithdrawal() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.admin.withdrawals.approve.path, { id });
      const res = await fetch(url, { method: "POST", credentials: "include" });
      if (!res.ok) throw new Error("Failed to approve withdrawal");
      return api.admin.withdrawals.approve.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.admin.withdrawals.list.path] });
    },
  });
}

// POST /api/admin/withdrawals/:id/reject
export function useRejectWithdrawal() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.admin.withdrawals.reject.path, { id });
      const res = await fetch(url, { method: "POST", credentials: "include" });
      if (!res.ok) throw new Error("Failed to reject withdrawal");
      return api.admin.withdrawals.reject.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.admin.withdrawals.list.path] });
    },
  });
}
