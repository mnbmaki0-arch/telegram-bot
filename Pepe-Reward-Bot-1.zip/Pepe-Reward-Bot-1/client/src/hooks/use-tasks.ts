import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type Task, buildUrl } from "@shared/routes";

// GET /api/tasks
export function useTasks() {
  return useQuery({
    queryKey: [api.tasks.list.path],
    queryFn: async () => {
      const res = await fetch(api.tasks.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch tasks");
      return api.tasks.list.responses[200].parse(await res.json());
    },
  });
}

// POST /api/tasks/:id/complete
export function useCompleteTask() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.tasks.complete.path, { id });
      const res = await fetch(url, { method: "POST", credentials: "include" });
      
      if (!res.ok) {
        if (res.status === 400) {
           const error = api.tasks.complete.responses[400].parse(await res.json());
           throw new Error(error.message);
        }
        if (res.status === 404) throw new Error("Task not found");
        throw new Error("Failed to complete task");
      }
      return api.tasks.complete.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.tasks.list.path] });
      queryClient.invalidateQueries({ queryKey: ["/api/profiles/me"] }); // Update balance
    },
  });
}

// POST /api/admin/tasks (Create Task)
export function useCreateTask() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: Omit<Task, "id">) => {
      const validated = api.admin.tasks.create.input.parse(data);
      const res = await fetch(api.admin.tasks.create.path, {
        method: api.admin.tasks.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to create task");
      return api.admin.tasks.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.tasks.list.path] });
    },
  });
}
