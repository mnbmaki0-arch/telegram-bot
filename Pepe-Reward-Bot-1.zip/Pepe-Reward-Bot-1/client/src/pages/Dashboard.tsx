import { useAuth } from "@/hooks/use-auth";
import { useProfile, useUpdateProfile } from "@/hooks/use-profile";
import { useTransactions } from "@/hooks/use-transactions";
import { useTasks } from "@/hooks/use-tasks";
import { Layout } from "@/components/Layout";
import { StatCard } from "@/components/StatCard";
import { Coins, TrendingUp, CalendarCheck, Wallet } from "lucide-react";
import { format } from "date-fns";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";

export default function Dashboard() {
  const { user } = useAuth();
  const { data: profile } = useProfile();
  const { data: transactions } = useTransactions();
  const { data: tasks } = useTasks();
  
  const updateProfile = useUpdateProfile();
  const { toast } = useToast();
  const [telegramUsername, setTelegramUsername] = useState(profile?.telegramUsername || "");
  const [isProfileOpen, setIsProfileOpen] = useState(false);

  const completedTasks = tasks?.filter(t => t.completed).length || 0;
  const totalTasks = tasks?.length || 0;
  
  const handleUpdateProfile = () => {
    updateProfile.mutate({ telegramUsername }, {
      onSuccess: () => {
        toast({ title: "Profile Updated", description: "Your Telegram username has been saved." });
        setIsProfileOpen(false);
      },
      onError: () => {
        toast({ title: "Error", description: "Failed to update profile.", variant: "destructive" });
      }
    });
  };

  const recentTransactions = transactions?.slice(0, 5) || [];

  return (
    <Layout>
      <div className="flex flex-col gap-8">
        {/* Header Section */}
        <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4"
        >
            <div>
                <h1 className="text-3xl font-display font-bold text-white">
                    Welcome back, {user?.firstName || "Pepe Fan"}!
                </h1>
                <p className="text-muted-foreground mt-1">Here's what's happening with your rewards today.</p>
            </div>

            <Dialog open={isProfileOpen} onOpenChange={setIsProfileOpen}>
                <DialogTrigger asChild>
                    <Button variant="outline" className="border-primary/20 text-primary hover:bg-primary/10 hover:text-primary">
                        Edit Profile
                    </Button>
                </DialogTrigger>
                <DialogContent className="bg-secondary border-border">
                    <DialogHeader>
                        <DialogTitle>Update Profile</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                        <div className="space-y-2">
                            <label className="text-sm font-medium">Telegram Username</label>
                            <Input 
                                placeholder="@username" 
                                value={telegramUsername}
                                onChange={(e) => setTelegramUsername(e.target.value)}
                                className="bg-background border-border"
                            />
                        </div>
                        <Button 
                            className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
                            onClick={handleUpdateProfile}
                            disabled={updateProfile.isPending}
                        >
                            {updateProfile.isPending ? "Saving..." : "Save Changes"}
                        </Button>
                    </div>
                </DialogContent>
            </Dialog>
        </motion.div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard 
                title="Total Balance" 
                value={`${profile?.balance || 0} PEPE`} 
                icon={<Wallet className="h-6 w-6" />}
                className="bg-gradient-to-br from-secondary to-primary/5 border-primary/20"
            />
            <StatCard 
                title="Tasks Done" 
                value={`${completedTasks}/${totalTasks}`} 
                icon={<CalendarCheck className="h-6 w-6" />}
            />
            <StatCard 
                title="Pending Withdrawal" 
                value="0 PEPE" 
                icon={<TrendingUp className="h-6 w-6" />}
            />
            <StatCard 
                title="Referrals" 
                value="0" 
                icon={<Coins className="h-6 w-6" />}
            />
        </div>

        {/* Recent Activity */}
        <div className="glass-card rounded-2xl p-6">
            <h2 className="text-xl font-bold text-white mb-6">Recent Activity</h2>
            
            {recentTransactions.length > 0 ? (
                <div className="space-y-4">
                    {recentTransactions.map((tx) => (
                        <div key={tx.id} className="flex items-center justify-between p-4 rounded-xl bg-background/50 border border-white/5">
                            <div className="flex items-center gap-4">
                                <div className={`p-3 rounded-full ${tx.type === 'deposit' || tx.type === 'reward' ? 'bg-green-500/10 text-green-500' : 'bg-red-500/10 text-red-500'}`}>
                                    {tx.type === 'deposit' || tx.type === 'reward' ? <TrendingUp className="h-4 w-4" /> : <Wallet className="h-4 w-4" />}
                                </div>
                                <div>
                                    <p className="font-medium text-white capitalize">{tx.type}</p>
                                    <p className="text-xs text-muted-foreground">{format(new Date(tx.createdAt || new Date()), "PPP")}</p>
                                </div>
                            </div>
                            <div className="text-right">
                                <p className={`font-bold ${tx.type === 'deposit' || tx.type === 'reward' ? 'text-green-500' : 'text-white'}`}>
                                    {tx.type === 'withdrawal' ? '-' : '+'}{tx.amount} PEPE
                                </p>
                                <p className={`text-xs px-2 py-0.5 rounded-full inline-block mt-1 capitalize ${
                                    tx.status === 'completed' ? 'bg-green-500/10 text-green-500' : 
                                    tx.status === 'rejected' ? 'bg-red-500/10 text-red-500' : 
                                    'bg-yellow-500/10 text-yellow-500'
                                }`}>
                                    {tx.status}
                                </p>
                            </div>
                        </div>
                    ))}
                </div>
            ) : (
                <div className="text-center py-10 text-muted-foreground">
                    <p>No recent activity. Start earning PEPE today!</p>
                </div>
            )}
        </div>
      </div>
    </Layout>
  );
}
