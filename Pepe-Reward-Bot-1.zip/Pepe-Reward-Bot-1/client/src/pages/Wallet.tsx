import { Layout } from "@/components/Layout";
import { useProfile } from "@/hooks/use-profile";
import { useTransactions, useWithdraw } from "@/hooks/use-transactions";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { Wallet as WalletIcon, ArrowUpRight, ArrowDownLeft, History } from "lucide-react";
import { format } from "date-fns";
import { z } from "zod";

export default function Wallet() {
  const { data: profile } = useProfile();
  const { data: transactions } = useTransactions();
  const withdraw = useWithdraw();
  const { toast } = useToast();
  
  const [withdrawAmount, setWithdrawAmount] = useState("");
  const [withdrawAddress, setWithdrawAddress] = useState("");
  const [isWithdrawOpen, setIsWithdrawOpen] = useState(false);
  const [isDepositOpen, setIsDepositOpen] = useState(false);

  const handleWithdraw = () => {
    const amount = parseInt(withdrawAmount);
    
    // Basic validation
    if (!withdrawAddress.trim()) {
      toast({ title: "Missing Address", description: "Please enter your wallet address.", variant: "destructive" });
      return;
    }

    if (isNaN(amount) || amount <= 0) {
      toast({ title: "Invalid Amount", description: "Please enter a valid positive number.", variant: "destructive" });
      return;
    }

    if (amount > (profile?.balance || 0)) {
       toast({ title: "Insufficient Funds", description: "You cannot withdraw more than your balance.", variant: "destructive" });
       return;
    }

    withdraw.mutate({ amount }, {
      onSuccess: () => {
        toast({ title: "Request Sent", description: "Your withdrawal request has been submitted for approval." });
        setIsWithdrawOpen(false);
        setWithdrawAmount("");
        setWithdrawAddress("");
      },
      onError: (err) => {
        toast({ title: "Error", description: err.message, variant: "destructive" });
      }
    });
  };

  return (
    <Layout>
      <div className="max-w-4xl mx-auto space-y-8">
        <h1 className="text-3xl font-display font-bold text-white">My Wallet</h1>

        {/* Balance Card */}
        <div className="bg-gradient-to-r from-primary/20 to-secondary border border-primary/20 rounded-3xl p-8 relative overflow-hidden">
             <div className="absolute top-0 right-0 p-8 opacity-10">
                <WalletIcon className="w-32 h-32 text-primary" />
             </div>
             
             <div className="relative z-10">
                 <p className="text-muted-foreground font-medium mb-2">Available Balance</p>
                 <h2 className="text-5xl font-display font-bold text-white mb-8">{profile?.balance || 0} <span className="text-primary text-3xl">PEPE</span></h2>
                 
                 <div className="flex gap-4 flex-wrap">
                   {/* Deposit Dialog */}
                   <Dialog open={isDepositOpen} onOpenChange={setIsDepositOpen}>
                      <DialogTrigger asChild>
                          <Button data-testid="button-deposit" className="bg-green-600 text-white font-bold px-8 py-6 rounded-xl shadow-lg shadow-green-600/25 hover:scale-105 transition-transform">
                              Deposit <ArrowDownLeft className="ml-2 w-5 h-5" />
                          </Button>
                      </DialogTrigger>
                      <DialogContent className="bg-secondary border-border">
                          <DialogHeader>
                              <DialogTitle>Deposit PEPE Tokens</DialogTitle>
                          </DialogHeader>
                          <div className="py-6 space-y-4">
                              <div className="bg-background/50 p-4 rounded-lg border border-white/5">
                                  <p className="text-sm text-muted-foreground mb-1">Network</p>
                                  <p className="text-sm font-bold text-white" data-testid="text-network">ERC20</p>
                              </div>
                              
                              <div className="bg-background/50 p-4 rounded-lg border border-white/5">
                                  <p className="text-sm text-muted-foreground mb-1">Deposit Address</p>
                                  <p className="text-xs font-mono text-white break-all select-all" data-testid="text-deposit-address">0xe2deb105d5ff005a30398a2f19a0c4a2a1e8da42</p>
                              </div>
                          </div>
                      </DialogContent>
                   </Dialog>

                   {/* Withdraw Dialog */}
                   <Dialog open={isWithdrawOpen} onOpenChange={setIsWithdrawOpen}>
                      <DialogTrigger asChild>
                          <Button data-testid="button-withdraw" className="bg-primary text-primary-foreground font-bold px-8 py-6 rounded-xl shadow-lg shadow-primary/25 hover:scale-105 transition-transform">
                              Withdraw Funds <ArrowUpRight className="ml-2 w-5 h-5" />
                          </Button>
                      </DialogTrigger>
                      <DialogContent className="bg-secondary border-border">
                          <DialogHeader>
                              <DialogTitle>Request Withdrawal</DialogTitle>
                          </DialogHeader>
                          <div className="py-6 space-y-4">
                              <div className="bg-background/50 p-4 rounded-lg border border-white/5">
                                  <p className="text-sm text-muted-foreground">Available to withdraw</p>
                                  <p className="text-xl font-bold text-white">{profile?.balance || 0} PEPE</p>
                              </div>
                              
                              <div className="space-y-2">
                                  <label className="text-sm font-medium">Withdraw Address</label>
                                  <Input 
                                      type="text"
                                      placeholder="Enter your wallet address"
                                      value={withdrawAddress}
                                      onChange={(e) => setWithdrawAddress(e.target.value)}
                                      className="bg-background border-border font-mono text-xs"
                                      data-testid="input-withdraw-address"
                                  />
                              </div>
                              
                              <div className="space-y-2">
                                  <label className="text-sm font-medium">Amount to withdraw</label>
                                  <Input 
                                      type="number"
                                      placeholder="Min. 1000"
                                      value={withdrawAmount}
                                      onChange={(e) => setWithdrawAmount(e.target.value)}
                                      className="bg-background border-border"
                                      data-testid="input-withdraw-amount"
                                  />
                              </div>
                              
                              <Button 
                                  className="w-full bg-primary text-primary-foreground font-bold py-6"
                                  onClick={handleWithdraw}
                                  disabled={withdraw.isPending}
                                  data-testid="button-confirm-withdraw"
                              >
                                  {withdraw.isPending ? "Processing..." : "Confirm Withdrawal"}
                              </Button>
                          </div>
                      </DialogContent>
                   </Dialog>
                 </div>
             </div>
        </div>

        {/* Transaction History */}
        <div className="glass-card rounded-2xl p-6">
            <div className="flex items-center gap-3 mb-6 border-b border-white/5 pb-4">
                <History className="text-primary h-5 w-5" />
                <h3 className="text-xl font-bold text-white">Transaction History</h3>
            </div>
            
            <div className="space-y-3">
                {transactions?.map((tx) => (
                    <div key={tx.id} className="flex items-center justify-between p-4 rounded-xl bg-background/30 hover:bg-background/50 transition-colors border border-white/5">
                         <div>
                             <p className="font-bold text-white capitalize">{tx.type}</p>
                             <p className="text-xs text-muted-foreground">{format(new Date(tx.createdAt || new Date()), "PPP p")}</p>
                         </div>
                         <div className="text-right">
                             <span className={`font-mono font-bold text-lg ${tx.type === 'withdrawal' ? 'text-white' : 'text-primary'}`}>
                                 {tx.type === 'withdrawal' ? '-' : '+'}{tx.amount}
                             </span>
                             <div className={`text-[10px] font-bold uppercase tracking-wider mt-1 ${
                                 tx.status === 'completed' ? 'text-green-500' : 
                                 tx.status === 'rejected' ? 'text-red-500' : 
                                 'text-yellow-500'
                             }`}>
                                 {tx.status}
                             </div>
                         </div>
                    </div>
                ))}
                
                {transactions?.length === 0 && (
                    <p className="text-center text-muted-foreground py-8">No transactions yet.</p>
                )}
            </div>
        </div>
      </div>
    </Layout>
  );
}
