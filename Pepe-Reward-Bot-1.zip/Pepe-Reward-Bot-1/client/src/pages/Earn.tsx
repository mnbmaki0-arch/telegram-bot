import { Layout } from "@/components/Layout";
import { useTasks, useCompleteTask } from "@/hooks/use-tasks";
import { motion } from "framer-motion";
import { CheckCircle2, Loader2, ExternalLink, Gift, UserPlus, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

export default function Earn() {
  const { data: tasks, isLoading } = useTasks();
  const completeTask = useCompleteTask();
  const { toast } = useToast();

  const handleComplete = async (taskId: number, taskType: string, link?: string | null) => {
    if (link) {
        window.open(link, '_blank');
    }

    // Simulate verification delay for UX
    setTimeout(() => {
        completeTask.mutate(taskId, {
            onSuccess: (data) => {
                toast({
                    title: "Task Completed!",
                    description: `You earned ${data.reward} PEPE!`,
                });
            },
            onError: (err) => {
                toast({
                    title: "Error",
                    description: err.message,
                    variant: "destructive",
                });
            }
        });
    }, taskType === 'social_join' ? 2000 : 500);
  };

  const getIcon = (type: string) => {
    switch(type) {
        case 'daily_login': return <Gift className="h-6 w-6 text-yellow-500" />;
        case 'social_join': return <Users className="h-6 w-6 text-blue-500" />;
        case 'referral': return <UserPlus className="h-6 w-6 text-purple-500" />;
        default: return <Gift className="h-6 w-6" />;
    }
  };

  return (
    <Layout>
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
            <h1 className="text-3xl font-display font-bold text-white mb-2">Earn PEPE</h1>
            <p className="text-muted-foreground">Complete simple tasks to grow your balance instantly.</p>
        </div>

        {isLoading ? (
            <div className="flex justify-center py-20">
                <Loader2 className="h-10 w-10 animate-spin text-primary" />
            </div>
        ) : (
            <div className="grid gap-4">
                {tasks?.map((task, idx) => (
                    <motion.div
                        key={task.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: idx * 0.1 }}
                        className={`glass-card p-6 rounded-2xl flex items-center justify-between group ${task.completed ? 'opacity-60 grayscale' : 'hover:border-primary/30'}`}
                    >
                        <div className="flex items-center gap-4">
                            <div className="h-12 w-12 rounded-xl bg-background/50 flex items-center justify-center border border-white/5">
                                {getIcon(task.type)}
                            </div>
                            <div>
                                <h3 className="font-bold text-white text-lg">{task.title}</h3>
                                <p className="text-sm text-muted-foreground">{task.description}</p>
                                <div className="mt-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary/10 text-primary">
                                    +{task.rewardAmount} PEPE
                                </div>
                            </div>
                        </div>

                        {task.completed ? (
                            <div className="flex items-center gap-2 text-primary font-bold px-6">
                                <CheckCircle2 className="h-6 w-6" />
                                <span>Done</span>
                            </div>
                        ) : (
                            <Button 
                                onClick={() => handleComplete(task.id, task.type, task.link)}
                                disabled={completeTask.isPending}
                                className="bg-primary hover:bg-primary/90 text-primary-foreground font-bold px-6 py-6 rounded-xl shadow-lg shadow-primary/20 hover:translate-y-[-2px] transition-all"
                            >
                                {completeTask.isPending ? (
                                    <Loader2 className="h-5 w-5 animate-spin" />
                                ) : (
                                    <>
                                        {task.type === 'social_join' ? 'Join' : 'Claim'}
                                        {task.type === 'social_join' && <ExternalLink className="ml-2 h-4 w-4" />}
                                    </>
                                )}
                            </Button>
                        )}
                    </motion.div>
                ))}

                {tasks?.length === 0 && (
                    <div className="text-center py-10 glass-card rounded-2xl">
                        <p className="text-muted-foreground">No active tasks right now. Check back later!</p>
                    </div>
                )}
            </div>
        )}
      </div>
    </Layout>
  );
}
