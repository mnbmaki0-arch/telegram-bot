import { Layout } from "@/components/Layout";
import { useAuth } from "@/hooks/use-auth";
import { useProfile } from "@/hooks/use-profile";
import { useAdminWithdrawals, useApproveWithdrawal, useRejectWithdrawal, useCreateTask, useTasks } from "@/hooks/use-tasks"; // Note: imports adjusted based on hooks file structure, assuming custom hooks are available
import { useAdminWithdrawals as useAdminW, useApproveWithdrawal as useApprove, useRejectWithdrawal as useReject } from "@/hooks/use-transactions";
import { useTasks as useAllTasks, useCreateTask as useCreateNewTask } from "@/hooks/use-tasks";
import { Redirect } from "wouter";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Check, X, Plus } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function Admin() {
  const { data: profile, isLoading: isProfileLoading } = useProfile();
  
  // Withdrawals Hooks
  const { data: withdrawals } = useAdminW();
  const approve = useApprove();
  const reject = useReject();
  
  // Tasks Hooks
  const { data: tasks } = useAllTasks();
  const createTask = useCreateNewTask();
  
  const { toast } = useToast();
  
  // Create Task Form State
  const [newTask, setNewTask] = useState({
    title: "",
    description: "",
    rewardAmount: "",
    type: "daily_login",
    link: "",
    active: true
  });

  if (isProfileLoading) return null;
  if (profile?.role !== "admin") return <Redirect to="/" />;

  const handleCreateTask = () => {
    if (!newTask.title || !newTask.rewardAmount) {
        toast({ title: "Error", description: "Title and Reward Amount are required", variant: "destructive" });
        return;
    }

    createTask.mutate({
        ...newTask,
        rewardAmount: parseInt(newTask.rewardAmount),
        active: true
    }, {
        onSuccess: () => {
            toast({ title: "Success", description: "Task created successfully" });
            setNewTask({ title: "", description: "", rewardAmount: "", type: "daily_login", link: "", active: true });
        }
    });
  };

  const pendingWithdrawals = withdrawals?.filter(w => w.status === 'pending') || [];

  return (
    <Layout>
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-8">
             <h1 className="text-3xl font-display font-bold text-white">Admin Dashboard</h1>
             <span className="px-3 py-1 rounded-full bg-destructive/20 text-destructive text-sm font-bold border border-destructive/20">
                ADMIN AREA
             </span>
        </div>

        <Tabs defaultValue="withdrawals" className="space-y-6">
            <TabsList className="bg-secondary p-1 rounded-xl">
                <TabsTrigger value="withdrawals" className="data-[state=active]:bg-background rounded-lg px-6">Withdrawals</TabsTrigger>
                <TabsTrigger value="tasks" className="data-[state=active]:bg-background rounded-lg px-6">Tasks Management</TabsTrigger>
            </TabsList>

            {/* WITHDRAWALS TAB */}
            <TabsContent value="withdrawals" className="space-y-6">
                <Card className="bg-secondary border-border">
                    <CardHeader>
                        <CardTitle className="text-white">Pending Requests ({pendingWithdrawals.length})</CardTitle>
                    </CardHeader>
                    <CardContent>
                        {pendingWithdrawals.length === 0 ? (
                            <p className="text-muted-foreground">No pending withdrawals.</p>
                        ) : (
                            <div className="space-y-3">
                                {pendingWithdrawals.map((w) => (
                                    <div key={w.id} className="flex items-center justify-between p-4 bg-background/50 rounded-xl border border-white/5">
                                        <div>
                                            <p className="font-bold text-white">{w.amount} PEPE</p>
                                            <p className="text-sm text-muted-foreground">User: {w.user?.username || "Unknown"}</p>
                                            <p className="text-xs text-muted-foreground font-mono mt-1">ID: {w.id}</p>
                                        </div>
                                        <div className="flex gap-2">
                                            <Button 
                                                size="sm" 
                                                className="bg-green-500/20 text-green-500 hover:bg-green-500/30"
                                                onClick={() => approve.mutate(w.id)}
                                                disabled={approve.isPending || reject.isPending}
                                            >
                                                <Check className="w-4 h-4 mr-1" /> Approve
                                            </Button>
                                            <Button 
                                                size="sm" 
                                                className="bg-red-500/20 text-red-500 hover:bg-red-500/30"
                                                onClick={() => reject.mutate(w.id)}
                                                disabled={approve.isPending || reject.isPending}
                                            >
                                                <X className="w-4 h-4 mr-1" /> Reject
                                            </Button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </CardContent>
                </Card>
            </TabsContent>

            {/* TASKS TAB */}
            <TabsContent value="tasks" className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                    {/* Create Task Form */}
                    <Card className="bg-secondary border-border">
                        <CardHeader>
                            <CardTitle className="text-white">Create New Task</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div>
                                <label className="text-sm font-medium mb-1 block">Title</label>
                                <Input 
                                    value={newTask.title} 
                                    onChange={e => setNewTask({...newTask, title: e.target.value})}
                                    className="bg-background"
                                />
                            </div>
                            <div>
                                <label className="text-sm font-medium mb-1 block">Description</label>
                                <Input 
                                    value={newTask.description} 
                                    onChange={e => setNewTask({...newTask, description: e.target.value})}
                                    className="bg-background"
                                />
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="text-sm font-medium mb-1 block">Reward (PEPE)</label>
                                    <Input 
                                        type="number"
                                        value={newTask.rewardAmount} 
                                        onChange={e => setNewTask({...newTask, rewardAmount: e.target.value})}
                                        className="bg-background"
                                    />
                                </div>
                                <div>
                                    <label className="text-sm font-medium mb-1 block">Type</label>
                                    <Select 
                                        value={newTask.type} 
                                        onValueChange={val => setNewTask({...newTask, type: val})}
                                    >
                                        <SelectTrigger className="bg-background">
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="daily_login">Daily Login</SelectItem>
                                            <SelectItem value="social_join">Social Join</SelectItem>
                                            <SelectItem value="referral">Referral</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                            </div>
                            {newTask.type === 'social_join' && (
                                <div>
                                    <label className="text-sm font-medium mb-1 block">Link URL</label>
                                    <Input 
                                        value={newTask.link} 
                                        onChange={e => setNewTask({...newTask, link: e.target.value})}
                                        className="bg-background"
                                        placeholder="https://t.me/..."
                                    />
                                </div>
                            )}
                            <Button 
                                onClick={handleCreateTask}
                                disabled={createTask.isPending}
                                className="w-full bg-primary text-primary-foreground font-bold mt-4"
                            >
                                {createTask.isPending ? "Creating..." : "Create Task"}
                            </Button>
                        </CardContent>
                    </Card>

                    {/* Task List */}
                    <Card className="bg-secondary border-border">
                        <CardHeader>
                            <CardTitle className="text-white">Existing Tasks</CardTitle>
                        </CardHeader>
                        <CardContent>
                             <div className="space-y-3 max-h-[500px] overflow-y-auto pr-2">
                                {tasks?.map((task) => (
                                    <div key={task.id} className="p-4 bg-background/50 rounded-xl border border-white/5">
                                        <div className="flex justify-between items-start">
                                            <h4 className="font-bold text-white">{task.title}</h4>
                                            <span className="text-xs bg-primary/20 text-primary px-2 py-1 rounded-full">{task.rewardAmount} PEPE</span>
                                        </div>
                                        <p className="text-sm text-muted-foreground mt-1">{task.type}</p>
                                    </div>
                                ))}
                             </div>
                        </CardContent>
                    </Card>
                </div>
            </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}
