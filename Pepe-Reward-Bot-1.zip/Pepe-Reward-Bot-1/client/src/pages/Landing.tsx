import { useAuth } from "@/hooks/use-auth";
import { Link } from "wouter";
import { ArrowRight, Zap, Shield, Gift } from "lucide-react";
import { motion } from "framer-motion";

export default function Landing() {
  const { isLoading } = useAuth();

  if (isLoading) return null;

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      {/* Background Gradients */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0">
         <div className="absolute -top-20 -left-20 w-96 h-96 bg-primary/20 rounded-full blur-[100px]" />
         <div className="absolute top-1/2 right-0 w-[500px] h-[500px] bg-primary/10 rounded-full blur-[120px]" />
      </div>

      <div className="relative z-10 max-w-6xl mx-auto px-6 py-20 lg:py-32 flex flex-col items-center text-center">
        <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
        >
             <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-secondary/50 border border-primary/20 mb-8 backdrop-blur-sm">
                <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
                <span className="text-sm font-medium text-primary-foreground">The #1 Pepe Reward Platform</span>
            </div>
            
            <h1 className="text-5xl lg:text-7xl font-display font-bold text-white leading-tight mb-6">
              Earn <span className="text-primary glow-text">PEPE</span> <br />
              While You Sleep
            </h1>
            
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed">
              Complete simple tasks, join our community, and watch your wallet grow. 
              The most transparent and rewarding crypto platform on Telegram.
            </p>
            
            <a href="/api/login" className="inline-flex items-center gap-3 px-8 py-4 bg-primary text-primary-foreground text-lg font-bold rounded-xl hover:bg-primary/90 hover:scale-105 transition-all duration-200 shadow-xl shadow-primary/20 group">
               Start Earning Now
               <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </a>
        </motion.div>

        {/* Features */}
        <div className="grid md:grid-cols-3 gap-6 mt-24 w-full">
            {[
                { icon: Zap, title: "Instant Tasks", desc: "Complete daily missions for instant rewards." },
                { icon: Shield, title: "Secure Wallet", desc: "Your PEPE is safe with our transparent ledger." },
                { icon: Gift, title: "Daily Bonuses", desc: "Login every day to multiply your earnings." }
            ].map((feature, idx) => (
                <motion.div 
                    key={idx}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 + (idx * 0.1), duration: 0.5 }}
                    className="p-8 rounded-2xl bg-secondary/30 border border-white/5 backdrop-blur-sm hover:border-primary/20 transition-all text-left"
                >
                    <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center text-primary mb-6">
                        <feature.icon className="w-6 h-6" />
                    </div>
                    <h3 className="text-xl font-bold text-white mb-2">{feature.title}</h3>
                    <p className="text-muted-foreground">{feature.desc}</p>
                </motion.div>
            ))}
        </div>
      </div>
    </div>
  );
}
