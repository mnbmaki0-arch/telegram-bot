import { db } from "./db";
import {
  profiles, transactions, tasks, userTasks, users,
  type Profile, type Transaction, type Task, type UserTask, type User,
  type InsertProfile, type InsertTransaction, type InsertTask, type InsertUserTask
} from "@shared/schema";
import { eq, desc, and } from "drizzle-orm";

export interface IStorage {
  // Profiles
  getProfile(userId: string): Promise<Profile | undefined>;
  createProfile(profile: InsertProfile): Promise<Profile>;
  updateProfile(userId: string, updates: Partial<Profile>): Promise<Profile>;

  // Transactions
  getTransactions(userId: string): Promise<Transaction[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  getPendingWithdrawals(): Promise<(Transaction & { user: User | null })[]>;
  updateTransactionStatus(id: number, status: string): Promise<Transaction>;

  // Tasks
  getTasks(): Promise<Task[]>;
  getTask(id: number): Promise<Task | undefined>;
  createTask(task: InsertTask): Promise<Task>;
  completeTask(userId: string, taskId: number, reward: number): Promise<void>;
  getUserCompletedTasks(userId: string): Promise<UserTask[]>;
}

export class DatabaseStorage implements IStorage {
  async getProfile(userId: string): Promise<Profile | undefined> {
    const [profile] = await db.select().from(profiles).where(eq(profiles.userId, userId));
    return profile;
  }

  async createProfile(profile: InsertProfile): Promise<Profile> {
    const [newProfile] = await db.insert(profiles).values(profile).returning();
    return newProfile;
  }

  async updateProfile(userId: string, updates: Partial<Profile>): Promise<Profile> {
    const [updated] = await db
      .update(profiles)
      .set(updates)
      .where(eq(profiles.userId, userId))
      .returning();
    return updated;
  }

  async getTransactions(userId: string): Promise<Transaction[]> {
    return await db
      .select()
      .from(transactions)
      .where(eq(transactions.userId, userId))
      .orderBy(desc(transactions.createdAt));
  }

  async createTransaction(transaction: InsertTransaction): Promise<Transaction> {
    const [newTransaction] = await db.insert(transactions).values(transaction).returning();
    return newTransaction;
  }

  async getPendingWithdrawals(): Promise<(Transaction & { user: User | null })[]> {
    const result = await db
      .select({
        transaction: transactions,
        user: users,
      })
      .from(transactions)
      .leftJoin(users, eq(transactions.userId, users.id))
      .where(and(eq(transactions.type, "withdrawal"), eq(transactions.status, "pending")))
      .orderBy(desc(transactions.createdAt));
    
    return result.map(r => ({ ...r.transaction, user: r.user }));
  }

  async updateTransactionStatus(id: number, status: "pending" | "completed" | "rejected"): Promise<Transaction> {
    const [updated] = await db
      .update(transactions)
      .set({ status })
      .where(eq(transactions.id, id))
      .returning();
    return updated;
  }

  async getTasks(): Promise<Task[]> {
    return await db.select().from(tasks).where(eq(tasks.active, true));
  }

  async getTask(id: number): Promise<Task | undefined> {
    const [task] = await db.select().from(tasks).where(eq(tasks.id, id));
    return task;
  }

  async createTask(task: InsertTask): Promise<Task> {
    const [newTask] = await db.insert(tasks).values(task).returning();
    return newTask;
  }

  async getUserCompletedTasks(userId: string): Promise<UserTask[]> {
    return await db.select().from(userTasks).where(eq(userTasks.userId, userId));
  }

  async completeTask(userId: string, taskId: number, reward: number): Promise<void> {
    await db.transaction(async (tx) => {
      // Record task completion
      await tx.insert(userTasks).values({ userId, taskId });
      
      // Update balance
      const [profile] = await tx.select().from(profiles).where(eq(profiles.userId, userId));
      if (profile) {
        await tx.update(profiles)
          .set({ balance: profile.balance + reward })
          .where(eq(profiles.userId, userId));
      } else {
        // Should exist, but handle safe
        await tx.insert(profiles).values({ userId, balance: reward, role: "user" });
      }

      // Record transaction
      await tx.insert(transactions).values({
        userId,
        type: "reward",
        amount: reward,
        status: "completed",
        description: `Task reward for task #${taskId}`,
      });
    });
  }
}

export const storage = new DatabaseStorage();
