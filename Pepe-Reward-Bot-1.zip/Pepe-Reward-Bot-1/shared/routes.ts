import { z } from 'zod';
import { insertTransactionSchema, insertTaskSchema, transactions, tasks, profiles, userTasks } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
  unauthorized: z.object({
    message: z.string(),
  }),
};

export const api = {
  profiles: {
    me: {
      method: 'GET' as const,
      path: '/api/profiles/me',
      responses: {
        200: z.custom<typeof profiles.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    update: {
      method: 'PATCH' as const,
      path: '/api/profiles/me',
      input: z.object({ telegramUsername: z.string().optional() }),
      responses: {
        200: z.custom<typeof profiles.$inferSelect>(),
      },
    },
  },
  transactions: {
    list: {
      method: 'GET' as const,
      path: '/api/transactions',
      responses: {
        200: z.array(z.custom<typeof transactions.$inferSelect>()),
      },
    },
    withdraw: {
      method: 'POST' as const,
      path: '/api/transactions/withdraw',
      input: z.object({ amount: z.coerce.number().min(1) }),
      responses: {
        201: z.custom<typeof transactions.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    deposit: {
      method: 'POST' as const,
      path: '/api/transactions/deposit',
      input: z.object({ amount: z.coerce.number().min(1) }),
      responses: {
        201: z.custom<typeof transactions.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
  },
  tasks: {
    list: {
      method: 'GET' as const,
      path: '/api/tasks',
      responses: {
        200: z.array(z.custom<typeof tasks.$inferSelect & { completed: boolean }>()),
      },
    },
    complete: {
      method: 'POST' as const,
      path: '/api/tasks/:id/complete',
      responses: {
        200: z.object({ message: z.string(), reward: z.number() }),
        400: errorSchemas.validation,
        404: errorSchemas.notFound,
      },
    },
  },
  admin: {
    withdrawals: {
      list: {
        method: 'GET' as const,
        path: '/api/admin/withdrawals',
        responses: {
          200: z.array(z.custom<typeof transactions.$inferSelect & { user: { username: string | null } }>()),
        },
      },
      approve: {
        method: 'POST' as const,
        path: '/api/admin/withdrawals/:id/approve',
        responses: {
          200: z.custom<typeof transactions.$inferSelect>(),
        },
      },
      reject: {
        method: 'POST' as const,
        path: '/api/admin/withdrawals/:id/reject',
        responses: {
          200: z.custom<typeof transactions.$inferSelect>(),
        },
      },
    },
    tasks: {
      create: {
        method: 'POST' as const,
        path: '/api/admin/tasks',
        input: insertTaskSchema,
        responses: {
          201: z.custom<typeof tasks.$inferSelect>(),
        },
      },
    }
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
