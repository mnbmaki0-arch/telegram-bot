import { pgTable, text, serial, integer, boolean, timestamp, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { users } from "./models/auth";
import { relations } from "drizzle-orm";

export * from "./models/auth";

export const profiles = pgTable("profiles", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  balance: integer("balance").default(0).notNull(), // PEPE tokens
  role: text("role", { enum: ["user", "admin"] }).default("user").notNull(),
  telegramUsername: text("telegram_username"),
});

export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  type: text("type", { enum: ["deposit", "withdrawal", "reward"] }).notNull(),
  amount: integer("amount").notNull(),
  status: text("status", { enum: ["pending", "completed", "rejected"] }).default("pending").notNull(),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  rewardAmount: integer("reward_amount").notNull(),
  active: boolean("active").default(true).notNull(),
  type: text("type", { enum: ["daily_login", "social_join", "referral"] }).notNull(),
  link: text("link"), // For social join tasks
});

export const userTasks = pgTable("user_tasks", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  taskId: integer("task_id").notNull().references(() => tasks.id),
  completedAt: timestamp("completed_at").defaultNow(),
});

// Relations
export const profilesRelations = relations(profiles, ({ one }) => ({
  user: one(users, {
    fields: [profiles.userId],
    references: [users.id],
  }),
}));

export const usersRelations = relations(users, ({ one, many }) => ({
  profile: one(profiles, {
    fields: [users.id],
    references: [profiles.userId],
  }),
  transactions: many(transactions),
  userTasks: many(userTasks),
}));

export const transactionsRelations = relations(transactions, ({ one }) => ({
  user: one(users, {
    fields: [transactions.userId],
    references: [users.id],
  }),
}));

export const userTasksRelations = relations(userTasks, ({ one }) => ({
  user: one(users, {
    fields: [userTasks.userId],
    references: [users.id],
  }),
  task: one(tasks, {
    fields: [userTasks.taskId],
    references: [tasks.id],
  }),
}));


// Schemas
export const insertProfileSchema = createInsertSchema(profiles).omit({ id: true });
export const insertTransactionSchema = createInsertSchema(transactions).omit({ id: true, createdAt: true, status: true });
export const insertTaskSchema = createInsertSchema(tasks).omit({ id: true });
export const insertUserTaskSchema = createInsertSchema(userTasks).omit({ id: true, completedAt: true });

export type Profile = typeof profiles.$inferSelect;
export type Transaction = typeof transactions.$inferSelect;
export type Task = typeof tasks.$inferSelect;
export type UserTask = typeof userTasks.$inferSelect;
